CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int NOT NULL,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Appointments (
    ID int IDENTITY (1,1),
    Vaxname varchar(255) NOT NULL,
    PUser varchar(255) NOT NULL,
    CUser varchar(255) NOT NULL,
    Time date NOT NULL,
    PRIMARY KEY (ID),
    FOREIGN KEY (Vaxname) REFERENCES Vaccines,
    FOREIGN KEY (PUser) REFERENCES Patients,
    FOREIGN KEY (CUser) REFERENCES Caregivers,
    UNIQUE(Time, CUser),
    FOREIGN KEY (Time, CUser) REFERENCES Availabilities
);
    