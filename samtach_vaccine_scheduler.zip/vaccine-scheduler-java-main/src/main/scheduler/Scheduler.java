package scheduler;

import scheduler.db.ConnectionManager;
import scheduler.model.Caregiver;
import scheduler.model.Patient;
import scheduler.model.Vaccine;
import scheduler.util.Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;
import java.util.ArrayList; // added for "search_caregiver_schedule" and helper methods
import java.util.List; // added for "search_caregiver_schedule" and helper methods

public class Scheduler {

    // objects to keep track of the currently logged-in user
    // Note: it is always true that at most one of currentCaregiver and currentPatient is not null
    //       since only one user can be logged-in at a time
    private static Caregiver currentCaregiver = null;
    private static Patient currentPatient = null;

    public static void main(String[] args) {
        // printing greetings text
        System.out.println();
        System.out.println("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!");
        System.out.println("*** Please enter one of the following commands ***");
        System.out.println("> create_patient <username> <password>");
        System.out.println("> create_caregiver <username> <password>");
        System.out.println("> login_patient <username> <password>");
        System.out.println("> login_caregiver <username> <password>");
        System.out.println("> search_caregiver_schedule <date>");
        System.out.println("> reserve <date> <vaccine>");
        System.out.println("> upload_availability <date>");
        System.out.println("> cancel <appointment_id>");
        System.out.println("> add_doses <vaccine> <number>");
        System.out.println("> show_appointments");
        System.out.println("> logout");
        System.out.println("> quit");
        System.out.println();

        // read input from user
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.print("> ");
            String response = "";
            try {
                response = r.readLine();
            } catch (IOException e) {
                System.out.println("Please try again!");
            }
            // split the user input by spaces
            String[] tokens = response.split(" ");
            // check if input exists
            if (tokens.length == 0) {
                System.out.println("Please try again!");
                continue;
            }
            // determine which operation to perform
            String operation = tokens[0];
            if (operation.equals("create_patient")) {
                createPatient(tokens);
            } else if (operation.equals("create_caregiver")) {
                createCaregiver(tokens);
            } else if (operation.equals("login_patient")) {
                loginPatient(tokens);
            } else if (operation.equals("login_caregiver")) {
                loginCaregiver(tokens);
            } else if (operation.equals("search_caregiver_schedule")) {
                searchCaregiverSchedule(tokens);
            } else if (operation.equals("reserve")) {
                reserve(tokens);
            } else if (operation.equals("upload_availability")) {
                uploadAvailability(tokens);
            } else if (operation.equals("cancel")) {
                cancel(tokens);
            } else if (operation.equals("add_doses")) {
                addDoses(tokens);
            } else if (operation.equals("show_appointments")) {
                showAppointments(tokens);
            } else if (operation.equals("logout")) {
                logout(tokens);
            } else if (operation.equals("quit")) {
                System.out.println("Bye!");
                return;
            } else {
                System.out.println("Invalid operation name!");
            }
        }
    }

    private static void createPatient(String[] tokens) {
        // create_patient <username> <password>
        // check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Failed to create user.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];
        // check 2: check if the username has been taken already
        if (usernameExistsPatient(username)) {
            System.out.println("Username taken, try again!");
            return;
        }
        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);
        // create the patient
        try {
            currentPatient = new Patient.PatientBuilder(username, salt, hash).build();
            // save patient information to our database
            currentPatient.saveToDB();
            System.out.println("Created user " + username);
        } catch (SQLException e) {
            System.out.println("Failed to create user.");
        }
    }

    // checks if a given username already exists in the Patients table of the database
    private static boolean usernameExistsPatient(String username) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Patients WHERE Username = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            // returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Please try again!");
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void createCaregiver(String[] tokens) {
        // create_caregiver <username> <password>
        // check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Failed to create user.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];
        // check 2: check if the username has been taken already
        if (usernameExistsCaregiver(username)) {
            System.out.println("Username taken, try again!");
            return;
        }
        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);
        // create the caregiver
        try {
            currentCaregiver = new Caregiver.CaregiverBuilder(username, salt, hash).build();
            // save to caregiver information to our database
            currentCaregiver.saveToDB();
            System.out.println("Created user " + username);
        } catch (SQLException e) {
            System.out.println("Failed to create user.");
            e.printStackTrace();
        }
    }

    private static boolean usernameExistsCaregiver(String username) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Caregivers WHERE Username = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            // returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Error occurred when checking username");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void loginPatient(String[] tokens) {
        // login_patient <username> <password>
        // check 1: if someone's already logged-in, they need to log out first
        if (currentCaregiver != null || currentPatient != null) {
            System.out.println("User already logged in.");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Login failed.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];

        Patient patient = null;
        try {
            patient = new Patient.PatientGetter(username, password).get();
        } catch (SQLException e) {
            System.out.println("Login failed.");
            e.printStackTrace();
        }
        // check if the login was successful
        if (patient == null) {
            System.out.println("Login failed.");
        } else {
            System.out.println("Logged in as: " + username);
            currentPatient = patient;
        }
    }

    private static void loginCaregiver(String[] tokens) {
        // login_caregiver <username> <password>
        // check 1: if someone's already logged-in, they need to log out first
        if (currentCaregiver != null || currentPatient != null) {
            System.out.println("User already logged in.");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Login failed.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];

        Caregiver caregiver = null;
        try {
            caregiver = new Caregiver.CaregiverGetter(username, password).get();
        } catch (SQLException e) {
            System.out.println("Login failed.");
            e.printStackTrace();
        }
        // check if the login was successful
        if (caregiver == null) {
            System.out.println("Login failed.");
        } else {
            System.out.println("Logged in as: " + username);
            currentCaregiver = caregiver;
        }
    }

    private static void searchCaregiverSchedule(String[] tokens) {
        // search_caregiver_schedule <date>
        // check 1: check if a user is logged-in
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first!");
        }
        // check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }
        String date = tokens[1];
        Date d = Date.valueOf(date);
        try {
            List<String> workingCaregivers = checkAvailability(d);
            List<String> vaccineDoses = getVaccineDoses();
            System.out.println("Available Caregivers:");
            for (String caregiver : workingCaregivers) {
                System.out.println(caregiver);
            }
            System.out.println("Available Vaccine Doses:");
            for (String vaccine : vaccineDoses) {
                System.out.println(vaccine);
            }
        } catch (SQLException e) {
            System.out.println("Please try again!");
        }
    }

    // returns the name of each vaccine along with the number of available doses as a string
    private static List<String> getVaccineDoses() throws SQLException {
        List<String> vaccineDoses = new ArrayList<>();
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();
        String getDoses = "SELECT Name, Doses FROM Vaccines";
        try {
            PreparedStatement vax = con.prepareStatement(getDoses);
            ResultSet results = vax.executeQuery();
            while (results.next()) {
                String name = results.getString("Name");
                int doses = results.getInt("Doses");
                vaccineDoses.add(name + " - " + doses);
            }
        } catch (SQLException e) {
            throw new SQLException();
        } finally {
            cm.closeConnection();
        }
        return vaccineDoses;
    }

    // returns a list of all available caregivers on the given date
    private static List<String> checkAvailability(Date d) throws SQLException {
        List<String> workingCaregivers = new ArrayList<>();
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String addAvailability = "SELECT Time, Username FROM Availabilities AS A WHERE Time = ? AND " +
                "NOT EXISTS (SELECT Time, CUser FROM Appointments AS P WHERE P.Time = A.Time and P.CUser = A.Username)" +
                " ORDER BY Username";
        try {
            PreparedStatement statement = con.prepareStatement(addAvailability);
            statement.setDate(1, d);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String username = resultSet.getString("Username");
                workingCaregivers.add(username);
            }
            return workingCaregivers;
        } catch (SQLException e) {
            throw new SQLException();
        } finally {
            cm.closeConnection();
        }
    }

    private static void reserve(String[] tokens) {
        // reserve <date> <vaccine>
        // check 1: check that a user is logged-in
        if (currentCaregiver == null && currentPatient == null) {
            System.out.println("Please login first!");
            return;
        }
        // check 2: check if the current logged-in user is a patient
        if (currentPatient == null) {
            System.out.println("Please login as a patient!");
            return;
        }
        // check 3: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }

        // check caregiver availability
        String date = tokens[1];
        String caregiverUsername;
        List<String> workingCaregivers = null;
        Date d = null;
        try {
            d = Date.valueOf(date);
            workingCaregivers = checkAvailability(d);
        } catch (SQLException | IllegalArgumentException e){
            System.out.println("Please try again!");
            return;
        }
        // check 4: there must be a caregiver working on the given date
        if (workingCaregivers.size() < 1) {
            System.out.println("No Caregiver is available!");
            return;
        } else {
            caregiverUsername = workingCaregivers.get(0);
        }

        // check vaccine availability
        String vaccineName = tokens[2];
        Vaccine vaccine;
        int numDoses;
        try {
            vaccine = new Vaccine.VaccineGetter(vaccineName).get();
            numDoses = checkDoses(vaccine);
        } catch (SQLException | IllegalArgumentException e) {
            System.out.println("Please try again!");
            return;
        }
        // check 5: there must be available doses
        if (numDoses == 0) {
            System.out.println("Not enough available doses!");
            return;
        }
        schedule(vaccine, caregiverUsername, d);
    }


    // adds an appointment to the Appointments table and prints out a confirmation
    private static void schedule(Vaccine vaccine, String caregiverUsername, Date d) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();
        String addAppointment = "INSERT INTO Appointments(Vaxname, PUser, CUser, Time)" +
                                " OUTPUT inserted.ID VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement appt = con.prepareStatement(addAppointment);
            con.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            con.setAutoCommit(false);

            appt.setString(1, vaccine.getVaccineName());
            appt.setString(2, currentPatient.getUsername());
            appt.setString(3, caregiverUsername);
            appt.setDate(4, d);
            ResultSet result = appt.executeQuery();
            int newAppointmentID = 0;
            while (result.next()) {
                newAppointmentID = result.getInt("ID");
            }
            if (newAppointmentID == 0) {
                throw new SQLException();
            }

            vaccine.decreaseAvailableDoses(1);

            con.commit();
            System.out.println("Appointment ID: " + newAppointmentID + ", Caregiver username: " + caregiverUsername);
        } catch (SQLException e) {
            try {
                System.out.println("Please try again!");
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            cm.closeConnection();
        }
    }

    // returns the number of available doses for the given vaccine
    private static int checkDoses(Vaccine vaccine) {
        if (vaccine == null) {
            throw new IllegalArgumentException();
        }
        return vaccine.getAvailableDoses();
    }

    private static void uploadAvailability(String[] tokens) {
        // upload_availability <date>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }
        String date = tokens[1];
        try {
            Date d = Date.valueOf(date);
            currentCaregiver.uploadAvailability(d);
            System.out.println("Availability uploaded!");
        } catch (IllegalArgumentException e) {
            System.out.println("Please enter a valid date!");
        } catch (SQLException e) {
            System.out.println("Error occurred when uploading availability");
            e.printStackTrace();
        }
    }

    private static void cancel(String[] tokens) {
        // cancel <appointment_id>
        // check 1: someone must be logged in
        if (currentCaregiver == null && currentPatient == null) {
            System.out.println("Please login first.");
        }
        // check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
        if (tokens.length != 2) {
            System.out.println("Please try again!");
        }
        int apptID = Integer.parseInt(tokens[1]);
        Vaccine vaccine;
        try {
            vaccine = new Vaccine.VaccineGetter(getVaxName(apptID)).get();
        } catch (SQLException e) {
            System.out.println("Please try again!");
            return;
        }
        cancel(apptID, vaccine);
    }

    // returns the vaccine name associated with the given appointment ID
    private static String getVaxName(int apptID) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();
        String vaccineName = "SELECT Vaxname FROM Appointments WHERE ID = ?";
        try {
            PreparedStatement vax = con.prepareStatement(vaccineName);
            vax.setInt(1, apptID);
            ResultSet results = vax.executeQuery();
            while (results.next()) {
                return results.getString("Vaxname");
            }
        } catch (SQLException e) {
            throw new SQLException();
        } finally {
            cm.closeConnection();
        }
        return null;
    }

    // cancels the given appointment and increases the available doses of the corresponding vaccine
    private static void cancel(int apptID, Vaccine vaccine) {
        if (vaccine == null) {
            System.out.println("Please try again!");
            return;
        }
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();
        String remAppointment = "DELETE FROM Appointments WHERE ID = ?";
        try {
            PreparedStatement appt = con.prepareStatement(remAppointment);
            con.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
            con.setAutoCommit(false);
            appt.setInt(1, apptID);
            appt.executeUpdate();

            vaccine.increaseAvailableDoses(1);

            con.commit();
            System.out.println("Appointment cancelled!");
        } catch (SQLException e) {
            try {
                System.out.println("Please try again!");
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        } finally {
            cm.closeConnection();
        }
    }
    private static void addDoses(String[] tokens) {
        // add_doses <vaccine> <number>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String vaccineName = tokens[1];
        int doses = Integer.parseInt(tokens[2]);
        Vaccine vaccine = null;
        try {
            vaccine = new Vaccine.VaccineGetter(vaccineName).get();
        } catch (SQLException e) {
            System.out.println("Error occurred when adding doses");
            e.printStackTrace();
        }
        // check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
        //          table
        if (vaccine == null) {
            try {
                vaccine = new Vaccine.VaccineBuilder(vaccineName, doses).build();
                vaccine.saveToDB();
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        } else {
            // if the vaccine is not null, meaning that the vaccine already exists in our table
            try {
                vaccine.increaseAvailableDoses(doses);
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        }
        System.out.println("Doses updated!");
    }

    private static void showAppointments(String[] tokens) {
        // show_appointments
        // check 1: someone must be logged in
        if (currentCaregiver == null && currentPatient == null) {
            System.out.println("Please login first.");
            return;
        }
        // check 2: the length for tokens need to be exactly 1 to include all information (with the operation name)
        if (tokens.length != 1) {
            System.out.println("Please try again!");
            return;
        }

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();
        String selectAppointments;
        if (currentPatient == null) {
            selectAppointments = "SELECT ID, Vaxname, Time, PUser FROM Appointments WHERE CUser = ? ORDER BY ID";
        } else {
            selectAppointments = "SELECT ID, Vaxname, Time, CUser FROM Appointments WHERE PUser = ? ORDER BY ID";
        }
        try {
            PreparedStatement statement = con.prepareStatement(selectAppointments);
            if (currentPatient == null) {
                statement.setString(1, currentCaregiver.getUsername());
            } else {
                statement.setString(1, currentPatient.getUsername());
            }
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                String ID = resultSet.getString("ID");
                String vaxname = resultSet.getString("Vaxname");
                Date time = resultSet.getDate("Time");
                String user;
                if (currentPatient == null) {
                    user = resultSet.getString("Puser");
                } else {
                    user = resultSet.getString("Cuser");
                }
                System.out.println(ID + " " + vaxname + " " + time.toString() + " " + user);
            }
        } catch (SQLException e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
    }

    private static void logout(String[] tokens) {
        // logout
        // check 1: someone must be logged in
        if (currentCaregiver == null && currentPatient == null) {
            System.out.println("Please login first.");
        }
        // check 2: the length for tokens need to be exactly 1 to include all information (with the operation name)
        if (tokens.length != 1) {
            System.out.println("Please try again!");
        }
        currentCaregiver = null;
        currentPatient = null;
        System.out.println("Successfully logged out!");
    }
}
